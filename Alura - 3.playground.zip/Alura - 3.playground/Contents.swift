let celsius = 30.5
let fahreneight = (celsius * 9/5) + 32

print("Em fahrenheit, a temperatura é de \(fahreneight)ºF.")

let nota01 = 8.0
let nota02 = 7.5
let nota03 = 9.0
let mediaDasNotas = (nota01 + nota02 + nota03) / 3

print("A média das notas é \(mediaDasNotas).")






