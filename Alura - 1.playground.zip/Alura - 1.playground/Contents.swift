var inicial: Character = "D"
var nome: String = "Diego"
var apelido: String = "Di"
var idade: Int = 21
var altura: Double = 1.70
var swift: Bool = true

print("inicial do Nome : \(inicial)")
print("Nome : \(nome)")
print("Apelido : \(inicial)")
print("Idade : \(idade)")
print("altura : \(altura)")
print("Gosta de Swift : \(swift)")




