1 + 2
10 - 2
8 * 2
10 / 2
5.0 / 2
5 % 2
4 % 2

(5 + 2) * 10

var numero1 = 10
var numero2 = 50
var soma = numero1 + numero2
print(soma)

numero1 += numero1 + 2

var nome = "Diego"
var sobrenome = "Andrade dos Santos"
print("meu nome é: \(nome) \(sobrenome)")

