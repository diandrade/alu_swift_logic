let pergunta = "Qual o valor de 8 x 2?"
let correto = 16





